# Build PPSA99288 (no PC toolchain needed)

1. Make a new **private** GitHub repo, upload everything in this folder (keep the `.github` folder).
2. Repo -> Actions -> "Build PPSA99288..." -> Run workflow.
3. When it finishes, download the artifact `PPSA99288-shadowmount`:
   - `PPSA99288.ffpfsc` -> the image ShadowMount Plus mounts
   - `PPSA99288.zip`    -> the app folder (eboot.bin, sce_sys, sce_module...)

Untested on a real runner: the pinned SDK/boilerplate/MkPFS steps were written from
source/native-app/README.md + gl/build.sh. If a step fails, the log shows which one.
